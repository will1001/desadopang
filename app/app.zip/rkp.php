<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class rkp extends Model
{
    //
    protected $fillable = ['tahun', 'urlgambar' ,'created_at', 'updated_at'];
}
