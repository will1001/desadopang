<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class kode_area_dusun extends Model
{
    //
    protected $fillable = ['Nama_Dusun', 'id_kadus','created_at', 'updated_at'];
}
