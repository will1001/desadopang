<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class pengumumandesa extends Model
{
    //
    protected $fillable = ['judulpengumuman', 'deskripsi', 'urlgambar' ,'created_at', 'updated_at'];
}
