<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class statagamapend extends Model
{
    //
    protected $fillable = ['agama', 'pria', 'wanita', 'jumlah' ,'created_at', 'updated_at'];
}
