<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class statpendidikanpend extends Model
{
    //
    protected $fillable = ['pendidikan', 'pria', 'wanita', 'jumlah' ,'created_at', 'updated_at'];
}
